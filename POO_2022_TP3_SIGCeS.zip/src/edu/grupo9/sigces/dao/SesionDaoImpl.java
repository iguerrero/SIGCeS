package edu.grupo9.sigces.dao;

public class SesionDaoImpl implements SesionDao{

}
