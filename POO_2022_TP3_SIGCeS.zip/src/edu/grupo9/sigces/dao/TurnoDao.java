package edu.grupo9.sigces.dao;

import edu.grupo9.sigces.Turno;

public interface TurnoDao {
    void generarNuevoTurno();
    void modificarTurno();
    void eliminarTurno();
}
