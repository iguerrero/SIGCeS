package edu.grupo9.sigces.dao;

public interface SesionDao {

}
